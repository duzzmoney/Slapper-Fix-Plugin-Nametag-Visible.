<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperHusk extends SlapperEntity {

    const TYPE_ID = 47;
    const HEIGHT = 1.95;

}
