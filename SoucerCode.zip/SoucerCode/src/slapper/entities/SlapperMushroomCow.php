<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperMushroomCow extends SlapperEntity {

    const TYPE_ID = 16;
    const HEIGHT = 1.4;

}
