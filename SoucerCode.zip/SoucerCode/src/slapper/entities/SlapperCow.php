<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperCow extends SlapperEntity {

    const TYPE_ID = 11;
    const HEIGHT = 1.4;

}
