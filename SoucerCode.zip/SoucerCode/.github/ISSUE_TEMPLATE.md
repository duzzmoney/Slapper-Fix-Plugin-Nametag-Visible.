<!--

NOTE:
- NO support provided for modified Slapper installations. THIS INCLUDES EDITING THE API VERSION.
- NO support will be provided for unofficial variants of PocketMine-MP. If you are not using PocketMine-MP, the issue will be closed.

-->
